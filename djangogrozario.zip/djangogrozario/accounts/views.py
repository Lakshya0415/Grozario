from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import get_user_model
from .forms import CustomAuthenticationForm, CustomUserCreationForm

def auth_view(request):
    if request.user.is_authenticated:
        return redirect('accounts:profile')

    login_form = CustomAuthenticationForm()
    signup_form = CustomUserCreationForm()

    if request.method == 'POST':
        if 'login' in request.POST:
            login_form = CustomAuthenticationForm(request, data=request.POST)
            if login_form.is_valid():
                email = login_form.cleaned_data.get('username')
                password = login_form.cleaned_data.get('password')
                user = authenticate(request, username=email, password=password)
                if user is not None:
                    login(request, user)
                    messages.success(request, 'Successfully logged in!')
                    return redirect('accounts:profile')
                else:
                    messages.error(request, 'Invalid email or password.')
            else:
                messages.error(request, 'Please correct the errors below.')

        elif 'signup' in request.POST:
            signup_form = CustomUserCreationForm(request.POST)
            if signup_form.is_valid():
                user = signup_form.save()
                login(request, user)
                messages.success(request, 'Account created successfully!')
                return redirect('accounts:profile')
            else:
                messages.error(request, 'Please correct the errors below.')

    return render(request, 'login.html', {
        'login_form': login_form,
        'signup_form': signup_form,
    })

@login_required
def profile_view(request):
    user = request.user
    context = {
        'user': user,
    }
    return render(request, 'profile.html', context) 