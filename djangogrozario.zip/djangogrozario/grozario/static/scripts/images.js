async function slider_imageArr_byOm(){
   let image_slider_arr =  [
        "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_savlon_itc_709.jpg?61e6f5b8bd0b7",
        "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_kitkat_nestle_659.jpg?61e6f5b7b1f82",
        "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_nutrition_nestle_710.jpg?61e6f5bb66855",
        "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_drinks_red%20bull_661.jpg?61e6f5bc851a4",
        "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_Britannia%20Biscuit_Britannia_569.jpg?61e6f5c0ca063",
        "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_Pepsi_Pepsico_714.jpg?61e6f5c4a1caa",
        "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_pc_himalaya_682.jpeg?61e6f59f3dc9b",
        "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=348/layout-engine/automation/pb_Brand_BREAKFAST_SLURP_673.jpeg?61e6f6231be92",
        "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=348/layout-engine/automation/pb_Brand_Mother%20Sparsh_Mother%20Sparsh_716.jpg?61e6f624ce2ff",
        "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=348/layout-engine/automation/pb_Brand_Mother%20Sparsh_Mother%20Sparsh_716.jpg?61e6f624ce2ff",
        // "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=321,h=200/layout-engine/2022-01/covid-not-over.jpg?61e79fa9a994b",
        "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_Gillette_PNG_711.jpg?61e6f5bd80f89"
    ];
    return image_slider_arr;
}

// let imageArr =  [
//     "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_savlon_itc_709.jpg?61e6f5b8bd0b7",
//     "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_kitkat_nestle_659.jpg?61e6f5b7b1f82",
//     "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_nutrition_nestle_710.jpg?61e6f5bb66855",
//     "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_drinks_red%20bull_661.jpg?61e6f5bc851a4",
//     "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_Britannia%20Biscuit_Britannia_569.jpg?61e6f5c0ca063",
//     "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_Pepsi_Pepsico_714.jpg?61e6f5c4a1caa",
//     "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_pc_himalaya_682.jpeg?61e6f59f3dc9b",
//     "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=348/layout-engine/automation/pb_Brand_BREAKFAST_SLURP_673.jpeg?61e6f6231be92",
//     "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=348/layout-engine/automation/pb_Brand_Mother%20Sparsh_Mother%20Sparsh_716.jpg?61e6f624ce2ff",
//     "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=348/layout-engine/automation/pb_Brand_Mother%20Sparsh_Mother%20Sparsh_716.jpg?61e6f624ce2ff",
//     "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=321,h=200/layout-engine/2022-01/covid-not-over.jpg?61e79fa9a994b",
//     "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=954,h=477/layout-engine/automation/pb_Brand_Gillette_PNG_711.jpg?61e6f5bd80f89"
// ];
// return image_slider_arr;
// return imageArr;
export default slider_imageArr_byOm;