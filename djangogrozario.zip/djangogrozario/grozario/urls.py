from django.urls import path, include
from django.views.generic import RedirectView
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('accounts/', include('accounts.urls')),
    path('login/', RedirectView.as_view(url='/accounts/login/', permanent=True)),
    path('addCategory/', views.add_category, name='addCategory'),
    path('address/', views.address_view, name='address'),
    path('map/', views.map_view, name='map'),
    path('category/', views.category_view, name='category'),
    path('vegetable-fruits/', views.vegetable_fruits_view, name='vegetable_fruits'),
    path('colddrink/', views.colddrink_view, name='colddrink'),
    path('coldrinks/soft/', views.soft_view, name='soft'),
    path('coldrinks/juices/', views.juices_view, name='juices'),
    path('coldrinks/soda/', views.soda_view, name='soda'),
    path('coldrinks/herbal/', views.herbal_view, name='herbal'),
    path('coldrinks/energy/', views.energy_view, name='energy'),
    path('coldrinks/water/', views.water_view, name='water'),
    path('grocery/', views.grocery_view, name='grocery'),
    path('grocery/pulses/', views.pulses_view, name='pulses'),
    path('grocery/atta/', views.atta_view, name='atta'),
    path('grocery/rice/', views.rice_view, name='rice'),
    path('grocery/dryfruits/', views.dryfruits_view, name='dryfruits'),
    path('grocery/oil/', views.oil_view, name='oil'),
    path('grocery/ghee/', views.ghee_view, name='ghee'),
    path('payment/', views.payment_view, name='payment'),
    path('personal-care/', views.personal_care, name='personal_care'),
    path('vegetables_fruits/fruits/', views.fruits_view, name='fruits'),
    path('vegetables_fruits/vegetable/', views.vegetable_view, name='vegetables'),
]





    

