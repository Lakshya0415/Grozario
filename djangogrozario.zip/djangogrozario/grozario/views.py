from django.shortcuts import render, redirect
# from django.shortcuts import render, redirect
# from django.contrib.auth import authenticate, login, logout
# from django.contrib.auth.models import User
# from .forms import SignUpForm, LoginForm
# from django.contrib import messages
from django.contrib.auth.decorators import login_required

def home_view(request):
    return render(request, 'index.html')

def login_view(request):
    return render(request, 'login.html')

def signup_view(request):
    # Signup logic yahan daalo
    return render(request, 'login.html')

def category_view(request):
    return render(request, 'category.html')

def grocery_view(request):
    return render(request, 'grocery.html')

def personal_care(request):
    return render(request, 'personalCare.html')

def colddrink_view(request):
    return render(request, 'colddrink.html')

def pulses_view(request):
    return render(request, '/grocery/pulses.html')

def atta_view(request):
    return render(request, '/grocery/atta.html')

def dryfruits_view(request):
    return render(request, '/grocery/dryfruits.html')

def soft_view(request):
    return render(request, '/coldrinks/soft.html')

def herbal_view(request):
    return render(request, '/coldrinks/herbal.html')

def water_view(request):
    return render(request, '/coldrinks/water.html')

def add_category(request):
    return render(request, 'addCategory.html')

def address_view(request):
    return render(request, 'address.html')

def map_view(request):
    return render(request, 'map.html')

def vegetable_fruits_view(request):
    return render(request, 'vegetable_fruits.html')

def fruits_view(request):
    return render(request, '/vegetable_fruits/fruits.html')

def vegetable_view(request):
    return render(request, '/vegetable_fruits/vegetable.html')

def rice_view(request):
    return render(request, '/grocery/rice.html')

def oil_view(request):
    return render(request, '/grocery/oil.html')

def ghee_view(request):
    return render(request, '/grocery/ghee.html')

def juices_view(request):
    return render(request, '/coldrinks/juices.html')

def soda_view(request):
    return render(request, '/coldrinks/soda.html')

def energy_view(request):
    return render(request, '/coldrinks/energy.html')

def personal_care_view(request):
    return render(request, '/personalCare/personal_care.html')

def payment_view(request):
    return render(request, 'payment.html')

# def signup_view(request):
#     if request.method == 'POST':
#         form = SignUpForm(request.POST)
#         if form.is_valid():
#             user = form.save(commit=False)
#             user.set_password(form.cleaned_data['password'])  # Hash password
#             user.save()
#             messages.success(request, "Account created successfully!")
#             return redirect('login')
#     else:
#         form = SignUpForm()
#     return render(request, 'login.html', {'form': form})

# def login_view(request):
#     if request.method == 'POST':
#         form = LoginForm(data=request.POST)
#         if form.is_valid():
#             user = form.get_user()
#             login(request, user)
#             messages.success(request, "Logged in successfully!")
#             return redirect('home')  # or your homepage
#     else:
#         form = LoginForm()
#     return render(request, 'login.html', {'form': form})

# def logout_view(request):
#     logout(request)
#     return redirect('login')





